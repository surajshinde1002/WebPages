package studentInfo;



import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/sbmt")
public class StudentData  extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private static final String query =  "insert into stuData(fName, lName, age) values(?, ?, ?)";


	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String fname = request.getParameter("fname");
		String lname = request.getParameter("lname");
		int age = Integer.parseInt(request.getParameter("age"));

		PrintWriter pw = response.getWriter();
		// Set Content type
		response.setContentType("text/html");

		// Load JDBC driver
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException cnf) {
			cnf.printStackTrace();
		}

		// Generate the connection
		try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "root");
				PreparedStatement ps = con.prepareStatement(query);) {

			ps.setString(1, fname);
			ps.setString(2, lname);
			ps.setInt(3, age);
			int count = ps.executeUpdate();
			if (count == 1) {
				pw.println("<h2>Record has been inserted</h2>");
			} else {
				pw.println("<h2>Record can't be registered</h2>");
			}

		} catch (SQLException se) {
			se.printStackTrace();
			pw.println("<h3>" + se.getMessage() + "</h3>");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
