package studentInfo;


import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/data")
public class ShowStudentData extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String query = "select fName, lName, age from stuData";

       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// Get PrintWriter
				PrintWriter pw = response.getWriter();
				// Set Content type
				response.setContentType("text/html");

				// Load JDBC driver
				try{
					Class.forName("com.mysql.cj.jdbc.Driver");
				}catch(ClassNotFoundException cnf) {
					cnf.printStackTrace();
				}
				
				// Generate the connection
				try(Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "root");
						PreparedStatement ps = con.prepareStatement(query);){
						ResultSet rs = ps.executeQuery();
						
						pw.println("<html>");
						pw.println("<head>"
								+ "<title>Book List Edit</title>"
								+"<link rel = 'stylesheet' href = 'css/bootstrap.css' />"
								+ "</head>"
								);
						
						pw.println("<body>");
						pw.println("<table border = '1' align = 'center' styles = 'margin:10rem'>");
						pw.println("<tr>");				
						pw.println("<th>First Name</th>");
						pw.println("<th>Last Name</th>");				
						pw.println("<th>Age</th>");				
						pw.println("</tr>");				
						while(rs.next()) {
							pw.println("<tr>");
							pw.println("<td>"+rs.getString(1)+"</td>");				
							pw.println("<td>"+rs.getString(2)+"</td>");				
							pw.println("<td>"+rs.getInt(3)+"</td>");			
							pw.println("</tr>");
						}
						pw.println("</table>");
						pw.println("</body>");
						pw.println("</html>");
				}catch(SQLException se) {
					se.printStackTrace();
					pw.println("<h3>"+se.getMessage()+"</h3>");
				}catch(Exception e) {
					e.printStackTrace();
				}
		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
