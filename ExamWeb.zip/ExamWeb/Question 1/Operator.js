console.log(document);
console.log(document.getElementById("x1"));

document.getElementById("x1").onclick = function(){

    var num = document.getElementById('i1').value;
    console.log(num);

  // program to check if a number is prime or not
let isPrime = true;

if (num === 1) {
    document.getElementById('a1').innerHTML = `
        Prime : <b>${num} </b>is neither prime nor composite number
    `;
}

// check if number is greater than 1
else if (num > 1) {

    // looping through 2 to number-1
    for (let i = 2; i < num; i++) {
        if (num % i == 0) {
            isPrime = false;
            break;
        }
    }

    if (isPrime) {
        document.getElementById('a1').innerHTML = `
        Prime : <b>${num} </b>is prime number
    `;
    } else {
        document.getElementById('a1').innerHTML = `
        Prime : <b>${num} </b> is not prime number
    `;;
    }
}

    else{
        document.getElementById('a1').innerHTML = `
        Prime : <b>${num} </b>is not a prime number
    `;
}


    var square = num * num;

        document.getElementById("a2").innerHTML = `
            Square is : <b>${square}<b>
        `;


    let reverse = 0;
        
        reverse = Number(String(num).split('').reverse().join(''));

        document.getElementById("a3").innerHTML = `
            Reverse is : <b>${reverse}<b>
        `;

}