
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/sbmt")
public class StudentInfo extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private static final String query = "insert into student(fName, lName, age) values(?, ?, ?)";

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String name = request.getParameter("name");
		String sirname = request.getParameter("sirname");
		int age = Integer.parseInt(request.getParameter("age"));

		PrintWriter out = response.getWriter();
		// Set Content type
		response.setContentType("text/html");

		// Load JDBC driver
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException nf) {
			nf.printStackTrace();
		}

		// Generate the connection
		try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "root");
				PreparedStatement ps = con.prepareStatement(query);) {

			ps.setString(1, name);
			ps.setString(2, sirname);
			ps.setInt(3, age);
			int count = ps.executeUpdate();
			if (count == 1) {
				out.println("<h2>Record has been inserted</h2>");
			} else {
				out.println("<h2>Record can't be registered</h2>");
			}

		} catch (SQLException se) {
			se.printStackTrace();
			out.println("<h3>" + se.getMessage() + "</h3>");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}